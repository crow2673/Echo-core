import time
import json
import sys
import os

# Ensure core folder is on path
sys.path.append(os.path.dirname(__file__))

from gpt_reasoner import gpt_reasoner  # import the module now visible

# Load or initialize core_state
try:
    with open("memory/core_state.json", "r") as f:
        core_state = json.load(f)
except FileNotFoundError:
    core_state = {"reasoning_history": [], "knowledge": {}, "X_flags": []}

def reasoning_cycle():
    # Loop over X_flags
    for x_flag in core_state.get("X_flags", []):
        result = gpt_reasoner(x_flag, core_state)
        core_state["reasoning_history"].append(result)
        core_state["knowledge"][x_flag] = result
        print(f"Processed {x_flag}: {result}")

    # Save state
    with open("memory/core_state.json", "w") as f:
        json.dump(core_state, f, indent=2)

if __name__ == "__main__":
    while True:
        print("Echo alive")
        reasoning_cycle()
        time.sleep(10)
